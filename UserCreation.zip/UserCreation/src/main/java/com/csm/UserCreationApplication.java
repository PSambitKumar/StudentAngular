package com.csm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserCreationApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserCreationApplication.class, args);
	}

}
