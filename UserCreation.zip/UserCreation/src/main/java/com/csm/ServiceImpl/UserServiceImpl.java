package com.csm.ServiceImpl;

import com.csm.Service.UserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
}
